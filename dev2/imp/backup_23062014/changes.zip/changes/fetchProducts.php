<?php

set_time_limit(0);
ini_set("memory_limit", "20000M");
include_once("config.php");

$start = (int)$_REQUEST['start'];
if(!$start){
	$start = 0;
}


$count = (int)$_REQUEST['count'];
if($count){
	$total = $db->func_query_first_cell("select count(model) from oc_product where status = 1");
	echo $total;
}
else{
	$all = (int)$_REQUEST['all'];
	if(!$all){
		$products = $db->func_query("select model from oc_product where status = 1 and date_modified < '".date('Y-m-d H:00:00')."' limit $start , 200");
	}
	else{
		$products = $db->func_query("select model from oc_product where status = 1 limit $start , 200");
	}

	if(count($products) == 0){
		echo "NO";
		exit;
	}

	print_r(json_encode($products));
}