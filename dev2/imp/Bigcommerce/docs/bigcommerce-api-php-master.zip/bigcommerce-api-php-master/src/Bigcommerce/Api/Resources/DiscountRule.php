<?php

namespace Bigcommerce\Api\Resources;

use Bigcommerce\Api\Resource;
use Bigcommerce\Api\Client;

/**
 * A bulk discount rule.
 */
class DiscountRule extends Resource
{

}
